
import tensorflow as tf
import tensorflow_transform as tft

import census_constants

# Unpack the contents of the constants module
_NUMERIC_FEATURE_KEYS = census_constants.NUMERIC_FEATURE_KEYS
_CATEGORICAL_FEATURE_KEYS = census_constants.CATEGORICAL_FEATURE_KEYS
_BUCKET_FEATURE_KEYS = census_constants.BUCKET_FEATURE_KEYS
_FEATURE_BUCKET_COUNT = census_constants.FEATURE_BUCKET_COUNT
_LABEL_KEY = census_constants.LABEL_KEY
_transformed_name = census_constants.transformed_name

def preprocessing_fn(inputs):
    outputs = {}

    # Scale numeric features to [0,1]
    for key in _NUMERIC_FEATURE_KEYS:
        # Ensure float type and dense tensor
        outputs[_transformed_name(key)] = tft.scale_to_0_1(
            tf.cast(inputs[key], tf.float32)
        )
    
    # Bucketize numeric features if needed
    for key in _BUCKET_FEATURE_KEYS:
        outputs[_transformed_name(key)] = tft.bucketize(
            tf.cast(inputs[key], tf.float32),
            _FEATURE_BUCKET_COUNT[key]
        )

    # Convert categorical strings to indices in a vocabulary
    for key in _CATEGORICAL_FEATURE_KEYS:
        outputs[_transformed_name(key)] = tft.compute_and_apply_vocabulary(
            inputs[key], num_oov_buckets=1
        )

    # Convert the label to index
    outputs[_transformed_name(_LABEL_KEY)] = tft.compute_and_apply_vocabulary(
        inputs[_LABEL_KEY]
    )

    return outputs
